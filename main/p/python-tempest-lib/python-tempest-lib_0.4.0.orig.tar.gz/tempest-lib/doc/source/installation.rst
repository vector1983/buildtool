============
Installation
============

At the command line::

    $ pip install tempest-lib

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv tempest-lib
    $ pip install tempest-lib