"""test failed import
"""
from __future__ import absolute_import, print_function
__revision__ = 0

def function():
    """yo"""
    from tutu import toto
    print(toto)
