"""The second thing."""
# pylint: disable=no-absolute-import
__revision__ = None
from .all_the_things import THING1

THING2 = "I am thing2"
THING1_PLUS_THING2 = "%s, plus %s" % (THING1, THING2)
