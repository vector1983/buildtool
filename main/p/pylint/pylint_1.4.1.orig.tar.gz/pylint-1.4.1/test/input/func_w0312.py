"""test mixed tabs and spaces"""
from __future__ import print_function
__revision__ = 1

def spaces_func():
    """yo"""
    print("yo")

def tab_func():
	"""yo"""
	print("yo")
