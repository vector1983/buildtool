Glance Store Library
=====================

Glance's stores library
