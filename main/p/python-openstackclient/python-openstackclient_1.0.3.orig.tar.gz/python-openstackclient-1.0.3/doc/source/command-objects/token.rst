=====
token
=====

Identity v2, v3

token issue
-----------

Issue new token

.. program:: token issue
.. code:: bash

    os token issue

token revoke
------------

*Identity version 2 only.*

Revoke existing token

.. program:: token revoke
.. code:: bash

    os token revoke
        <token>

.. describe:: <token>

    Token to be deleted
