=================
availability zone
=================

Compute v2

availability zone list
----------------------

List availability zones and their status

.. program availability zone list
.. code:: bash

    os availability zone list
        [--long]

.. option:: --long

    List additional fields in output
