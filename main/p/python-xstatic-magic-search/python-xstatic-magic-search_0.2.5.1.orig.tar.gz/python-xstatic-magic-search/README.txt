XStatic-MagicSearch
-------------------

MagicSearch is an AngularJS directive that provides a UI for both faceted
filtering and as-you-type filtering. It is intended for filtering tables,
such as an AngularJS smart-table, but it can be used in any situation
where you can provide it with facets/options and consume its events.

MagicSearch was initially developed by David Kavanagh for Eucalyptus.


MagicSearch javascript library packaged for setuptools (easy_install) / pip.

This package is intended to be used by **any** project that needs these files.

It intentionally does **not** provide any extra code except some metadata
**nor** has any extra requirements. You MAY use some minimal support code from
the XStatic base package, if you like.

You can find more info about the xstatic packaging way in the package `XStatic`.

