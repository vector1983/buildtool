#: E701
if a: a = False
#: E701
if not header or header[:6] != 'bytes=': return
#: E702
a = False; b = True
#: E702
import bdist_egg; bdist_egg.write_safety_flag(cmd.egg_info, safe)
#: E703
import shlex;
#: E702 E703
del a[:]; a.append(42);
#:
