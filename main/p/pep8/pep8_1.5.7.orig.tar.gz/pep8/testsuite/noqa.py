#: Okay
# silence E501
url = 'https://api.github.com/repos/sigmavirus24/Todo.txt-python/branches/master?client_id=xxxxxxxxxxxxxxxxxxxxxxxxxxxx&?client_secret=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'  # noqa

# silence E128
from functools import (partial, reduce, wraps,  # noqa
    cmp_to_key)

from functools import (partial, reduce, wraps,
    cmp_to_key)   # noqa

a = 1
if a == None:   # noqa
    pass
#:
