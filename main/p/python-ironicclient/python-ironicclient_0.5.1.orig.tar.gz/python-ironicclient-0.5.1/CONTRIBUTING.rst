If you would like to contribute to the development of OpenStack,
you must follow the steps documented at:

   http://docs.openstack.org/infra/manual/developers.html

More information on contributing can be found within the project
documentation:

   http://docs.openstack.org/developer/python-ironicclient/contributing.html
