raise SyntaxError
