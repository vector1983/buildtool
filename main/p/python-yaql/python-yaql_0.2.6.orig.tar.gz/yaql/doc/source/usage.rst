========
Usage
========

To use yaql in a project::

	import yaql