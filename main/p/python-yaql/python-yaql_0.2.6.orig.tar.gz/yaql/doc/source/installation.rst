============
Installation
============

At the command line::

    $ pip install yaql

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv yaql
    $ pip install yaql