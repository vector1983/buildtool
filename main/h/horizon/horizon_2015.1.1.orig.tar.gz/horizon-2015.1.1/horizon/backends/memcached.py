# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.
"""
An implementation of a cache binding using python-memcached
(with advanced options)
"""
import memcache_wrapper

import pickle

from django.core.cache.backends import memcached


class HorizonMemcached(memcached.BaseMemcachedCache):

    def __init__(self, server, params):
        """description of default variables.
        .. param:: self.socket_timeout
            number of seconds before sockets timeout

        .. param:: self.dead_retry
            number of seconds before retrying a dead server

        .. param:: self.server_retries
            how many times to try finding a free server
        """
        super(HorizonMemcached, self).__init__(
            server, params,
            library=memcache_wrapper,
            value_not_found_exception=ValueError)

        if getattr(self, '_options', None):
            self.socket_timeout = self._options.get('SOCKET_TIMEOUT', 3)
            self.dead_retry = self._options.get('DEAD_RETRY', 30)
            self.server_retries = self._options.get('SERVER_RETRIES', 10)

    @property
    def _cache(self):
        if getattr(self, '_client', None) is None:
            self._client = self._lib.HorizonClient(
                self._servers,
                pickleProtocol=pickle.HIGHEST_PROTOCOL,
                socket_timeout=self.socket_timeout,
                dead_retry=self.dead_retry,
                server_retries=self.server_retries)

        return self._client
