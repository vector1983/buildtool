"""Contributed Rackspace-specific resources."""
