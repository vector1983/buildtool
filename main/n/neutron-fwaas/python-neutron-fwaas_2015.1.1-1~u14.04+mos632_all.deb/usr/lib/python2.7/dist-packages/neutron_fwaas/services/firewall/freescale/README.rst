Freescale Firewall as a Service Plugin

* For more information, refer to:
    https://wiki.openstack.org/wiki/Freescale_Firewall_as_a_Service_Plugin

* For Information on Freescale CI, refer to:
    https://wiki.openstack.org/wiki/ThirdPartySystems/Freescale_CI

* Freescale CI contact:
    - fslosci@freescale.com
    - trinath.somanchi@freescale.com
