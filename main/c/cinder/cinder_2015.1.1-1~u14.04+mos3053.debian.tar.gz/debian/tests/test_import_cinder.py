try:
    import cinder
except ImportError, e:
    print "ERROR IMPORTING MODULE"
