try:
    import glance
except ImportError, e:
    print "ERROR IMPORTING MODULE"
