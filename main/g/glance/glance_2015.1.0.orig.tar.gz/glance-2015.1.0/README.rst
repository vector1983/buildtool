======
Glance
======

Glance is a project that defines services for discovering, registering,
retrieving and storing virtual machine images.

Use the following resources to learn more:

* `Official Glance documentation <http://docs.openstack.org/developer/glance/>`_
* `Official Client documentation <http://docs.openstack.org/developer/python-glanceclient/>`_
