from v1 import artifact as art1
from v2 import artifact as art2


MY_ARTIFACT = [art1.MyArtifact, art2.MyArtifact]
